#!/usr/bin/env bash
set -euo pipefail

project_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
jmeter_home=${JMETER_HOME:-/tmp/apache-jmeter-5.6.3}
jmeter=${jmeter_home}/bin/jmeter
results_dir=${1:-${project_root}/docs/evidence/local-2026-09-01/raw/performance/formal-2026-09-02}
runs=${MATERIALFLOW_PERF_RUNS:-3}
warmup_seconds=${MATERIALFLOW_PERF_WARMUP_SECONDS:-600}
measure_seconds=${MATERIALFLOW_PERF_MEASURE_SECONDS:-1200}
threads=${MATERIALFLOW_PERF_THREADS:-4}
rate_per_minute=${MATERIALFLOW_PERF_RATE_PER_MINUTE:-600}
gateway_port=${MATERIALFLOW_GATEWAY_PORT:-8081}
keycloak_port=${MATERIALFLOW_KEYCLOAK_PORT:-8180}
token_file=$(mktemp)
monitor_pid=

cleanup() {
  if [[ -n ${monitor_pid} ]]; then
    kill "${monitor_pid}" 2>/dev/null || true
    wait "${monitor_pid}" 2>/dev/null || true
  fi
  rm -f "${token_file}"
}
trap cleanup EXIT

if [[ ! -x ${jmeter} ]]; then
  printf 'JMeter is not executable at %s\n' "${jmeter}" >&2
  exit 1
fi
if [[ -e ${results_dir} ]]; then
  printf 'Refusing to overwrite existing performance evidence: %s\n' "${results_dir}" >&2
  exit 1
fi
mkdir -p "${results_dir}"
chmod 600 "${token_file}"

get_token() {
  local attempt response
  for attempt in $(seq 1 30); do
    if response=$(curl -fsS "http://localhost:${keycloak_port}/realms/materialflow/protocol/openid-connect/token" \
        -H 'Content-Type: application/x-www-form-urlencoded' \
        --data-urlencode 'client_id=materialflow-cli' \
        --data-urlencode 'grant_type=password' \
        --data-urlencode 'username=synthetic-demo' \
        --data-urlencode 'password=synthetic-demo-only'); then
      printf '%s' "${response}" | jq -er '.access_token' >"${token_file}"
      return
    fi
    sleep 2
  done
  printf 'Unable to obtain the synthetic performance-test token\n' >&2
  exit 1
}

capture_database() {
  local output=$1
  docker exec materialflow-postgres-1 psql -U materialflow -d materialflow -Atc \
    "select 'orders=' || count(*) from sales_orders;
     select 'outbox_pending=' || count(*) from outbox_events where status <> 'PUBLISHED';
     select 'lock_waiters=' || count(*) from pg_stat_activity where wait_event_type = 'Lock';
     select 'deadlocks=' || deadlocks || ',commits=' || xact_commit || ',rollbacks=' || xact_rollback || ',blks_hit=' || blks_hit || ',blks_read=' || blks_read from pg_stat_database where datname = 'materialflow';" \
    >"${output}"
}

monitor() {
  local output=$1
  while true; do
    printf 'timestamp=%s\n' "$(date -u +%FT%TZ)" >>"${output}"
    docker stats --no-stream --format '{{.Name}} cpu={{.CPUPerc}} memory={{.MemUsage}} net={{.NetIO}}' \
      materialflow-edge-gateway-1 materialflow-erp-core-1 materialflow-event-relay-1 \
      materialflow-postgres-1 materialflow-kafka-1 >>"${output}" 2>&1 || true
    docker exec materialflow-postgres-1 psql -U materialflow -d materialflow -Atc \
      "select 'lock_waiters=' || count(*) from pg_stat_activity where wait_event_type = 'Lock';" \
      >>"${output}" 2>&1 || true
    curl -fsS "http://localhost:8080/actuator/metrics/hikaricp.connections.active" \
      -H "Authorization: Bearer $(<"${token_file}")" \
      | jq -c '{metric:.name,value:(.measurements[0].value // null)}' >>"${output}" 2>/dev/null || true
    sleep 30
  done
}

summarize_jtl() {
  local run=$1 jtl=$2 output=$3 elapsed_file first_ms last_ms total success errors timeouts duration_ms
  local p50 p95 p99 throughput error_rate timeout_rate
  elapsed_file=$(mktemp)
  awk -F, 'NR > 1 {print $2}' "${jtl}" | sort -n >"${elapsed_file}"
  total=$(awk -F, 'NR > 1 {count++} END {print count+0}' "${jtl}")
  success=$(awk -F, 'NR > 1 && $8 == "true" {count++} END {print count+0}' "${jtl}")
  errors=$((total - success))
  timeouts=$(awk -F, 'NR > 1 && ($4 == "408" || $4 == "504" || tolower($5) ~ /timed out|timeout/) {count++} END {print count+0}' "${jtl}")
  first_ms=$(awk -F, 'NR == 2 {print $1}' "${jtl}")
  last_ms=$(awk -F, 'NR > 1 {value=$1+$2} END {print value}' "${jtl}")
  duration_ms=$((last_ms - first_ms))
  percentile() {
    local percent=$1 rank
    rank=$(( (total * percent + 99) / 100 ))
    sed -n "${rank}p" "${elapsed_file}"
  }
  p50=$(percentile 50)
  p95=$(percentile 95)
  p99=$(percentile 99)
  throughput=$(awk -v total="${total}" -v duration="${duration_ms}" 'BEGIN {printf "%.3f", total/(duration/1000)}')
  error_rate=$(awk -v errors="${errors}" -v total="${total}" 'BEGIN {printf "%.5f", 100*errors/total}')
  timeout_rate=$(awk -v timeouts="${timeouts}" -v total="${total}" 'BEGIN {printf "%.5f", 100*timeouts/total}')
  jq -n \
    --argjson run "${run}" --argjson samples "${total}" --argjson successes "${success}" \
    --argjson errors "${errors}" --argjson timeouts "${timeouts}" \
    --argjson p50_ms "${p50}" --argjson p95_ms "${p95}" --argjson p99_ms "${p99}" \
    --argjson throughput_rps "${throughput}" --argjson error_rate_percent "${error_rate}" \
    --argjson timeout_rate_percent "${timeout_rate}" \
    '{run:$run,samples:$samples,successes:$successes,errors:$errors,timeouts:$timeouts,
      p50_ms:$p50_ms,p95_ms:$p95_ms,p99_ms:$p99_ms,throughput_rps:$throughput_rps,
      error_rate_percent:$error_rate_percent,timeout_rate_percent:$timeout_rate_percent}' >"${output}"
  rm -f "${elapsed_file}"
}

{
  printf 'started_utc=%s\n' "$(date -u +%FT%TZ)"
  printf 'runs=%s warmup_seconds=%s measure_seconds=%s threads=%s rate_per_minute=%s\n' \
    "${runs}" "${warmup_seconds}" "${measure_seconds}" "${threads}" "${rate_per_minute}"
  uname -a
  lscpu | sed -n '1,24p'
  free -h
  java -version 2>&1
  "${jmeter}" --version 2>&1
  docker compose -f "${project_root}/deploy/compose/compose.yml" ps
} >"${results_dir}/environment.txt"
capture_database "${results_dir}/database-before.txt"

for run in $(seq 1 "${runs}"); do
  printf 'run=%s phase=warmup started=%s\n' "${run}" "$(date -u +%FT%TZ)"
  get_token
  "${jmeter}" -n -t "${project_root}/tests/performance/orders-load.jmx" \
    -Jhost=localhost -Jport="${gateway_port}" -Jthreads="${threads}" -Jramp=30 \
    -Jduration="${warmup_seconds}" -Jrate_per_minute="${rate_per_minute}" \
    -Jtoken_file="${token_file}" -l "${results_dir}/run-${run}-warmup.jtl" \
    -j "${results_dir}/run-${run}-warmup-jmeter.log"
  gzip -9 "${results_dir}/run-${run}-warmup.jtl"

  printf 'run=%s phase=measurement started=%s\n' "${run}" "$(date -u +%FT%TZ)"
  get_token
  monitor "${results_dir}/run-${run}-resource-samples.txt" &
  monitor_pid=$!
  "${jmeter}" -n -t "${project_root}/tests/performance/orders-load.jmx" \
    -Jhost=localhost -Jport="${gateway_port}" -Jthreads="${threads}" -Jramp=30 \
    -Jduration="${measure_seconds}" -Jrate_per_minute="${rate_per_minute}" \
    -Jtoken_file="${token_file}" -l "${results_dir}/run-${run}-measurement.jtl" \
    -j "${results_dir}/run-${run}-measurement-jmeter.log"
  kill "${monitor_pid}" 2>/dev/null || true
  wait "${monitor_pid}" 2>/dev/null || true
  monitor_pid=

  summarize_jtl "${run}" "${results_dir}/run-${run}-measurement.jtl" \
    "${results_dir}/run-${run}-summary.json"
  docker exec materialflow-kafka-1 /opt/kafka/bin/kafka-consumer-groups.sh \
    --bootstrap-server localhost:9092 --describe --all-groups \
    >"${results_dir}/run-${run}-kafka-groups.txt" 2>&1 || true
  capture_database "${results_dir}/run-${run}-database-after.txt"
  gzip -9 "${results_dir}/run-${run}-measurement.jtl"
  jq -c . "${results_dir}/run-${run}-summary.json"
done

capture_database "${results_dir}/database-after.txt"
jq -s '{runs:.,aggregate:{p50_ms:([.[].p50_ms]|sort|.[1]),p95_ms:([.[].p95_ms]|sort|.[1]),
  p99_ms:([.[].p99_ms]|sort|.[1]),throughput_rps:([.[].throughput_rps]|add/length),
  error_rate_percent:([.[].error_rate_percent]|add/length),timeout_rate_percent:([.[].timeout_rate_percent]|add/length)}}' \
  "${results_dir}"/run-*-summary.json >"${results_dir}/aggregate-summary.json"
printf 'completed_utc=%s\n' "$(date -u +%FT%TZ)" >>"${results_dir}/environment.txt"
jq . "${results_dir}/aggregate-summary.json"
