# MaterialFlow ERP

MaterialFlow ERP is a private, local-only Java 21 reference backend for a synthetic
building-material business. PostgreSQL is the source of truth; Redis and Kafka are
recoverable acceleration and integration planes.

## Implemented scope

- Modular transactional core for pricing, sales orders, credit, approval,
  inventory, procurement, fulfillment, invoicing, synthetic payment import and
  reconciliation.
- PostgreSQL idempotency, immutable ledgers/audit records, Transactional Outbox,
  Consumer Inbox, reservation expiry and fixed-order credit/inventory locking.
- Consumer failure classification keeps recoverable database work at the source
  with capped backoff, quarantines malformed envelopes, and exposes retry/DLQ
  metrics; real broker/database tests cover offsets and consumer restart.
- Kafka Relay with multi-instance `SKIP LOCKED` claiming, per-claim fencing,
  exhausted-lease recovery, bounded retry and dead lettering; Kafka Streams
  rebuildable projections.
- Reactive Gateway with optional Keycloak JWT validation, Redis rate limiting and
  fail-closed sensitive writes; Protocol Buffers/gRPC synthetic integrations with
  Resilience4j.
- Compose, Helm, optional safety-gated Terraform, OpenTelemetry, Prometheus,
  Grafana, Jaeger, CI gates, JMH and JMeter workloads.

This is a portfolio-scale reference implementation, not a production ERP. Claims
in `docs/evidence` distinguish `measured`, `derived`, `estimated`, and `unknown`.
No production SLA or unmeasured throughput is claimed.

The 2026-09-01 local verification index is
[`docs/evidence/local-2026-09-01/README.md`](docs/evidence/local-2026-09-01/README.md).
The formal three-run long-duration performance protocol, JWT/RBAC and tenant
isolation checks, kind Pod/rolling-update drills, and one complete
API-to-database-to-Outbox-to-Kafka-consumer trace are now locally verified. The
implementation remains an `implemented_local_reference`, not evidence of real
production tenure, customers, team ownership, cloud SLA, or past employment.
The [2026-09-06 reliability update](docs/evidence/local-2026-09-06/README.md)
adds verified Relay recovery and transactional consumer-metric fixes. It records
current tests separately from the historical performance/deployment baseline.
The corresponding Experience/Evidence Bank entries were authorized by the user
for this update; their synchronization record is in the new evidence index.
The [2026-09-07 consumer update](docs/evidence/local-2026-09-07/README.md)
adds database-outage retry classification and actual consumer-offset recovery
tests. Its [decision record](docs/adr/0006-consumer-failure-classification.md)
explains partition blocking and retained at-least-once delivery; the
[consumer runbook](docs/runbooks/consumer-recovery.md) covers diagnosis and replay.

Spring Boot 3.5.16 is retained for this bounded local update, but its OSS support
has ended. It is not a currently maintained production baseline. The
[market and maintenance review](docs/research/2026-09-06-market-and-maintenance.md)
documents Boot 4 migration costs and the remaining maintenance gap.

## Build

```bash
mvn verify
MATERIALFLOW_REDIS_PORT=6389 docker compose -f deploy/compose/compose.yml up -d
curl http://localhost:8081/actuator/health
```

If a default host port is occupied, override it, for example
`MATERIALFLOW_REDIS_PORT=6389 docker compose ...`. The API contract is
`contracts/openapi/materialflow-erp-v1.yaml`; all records in the demo migrations
are synthetic.

Infrastructure and local run instructions live in `deploy/compose` and
`docs/runbooks/local-development.md`. Architecture decisions and operational
recovery steps are under `docs/adr` and `docs/runbooks`.

## Privacy

All organizations, users, materials, prices, accounts, and transactions are
synthetic. This repository is intended to remain private and local. Do not publish,
push, or deploy it without separate authorization.
