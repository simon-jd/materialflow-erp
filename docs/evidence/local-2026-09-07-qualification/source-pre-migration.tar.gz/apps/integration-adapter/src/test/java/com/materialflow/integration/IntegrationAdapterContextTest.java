package com.materialflow.integration;

import static org.assertj.core.api.Assertions.assertThat;

import com.materialflow.integration.grpc.GrpcServerLifecycle;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = {
        "server.port=0",
        "materialflow.grpc.port=0",
        "management.tracing.enabled=false"
})
class IntegrationAdapterContextTest {
    @Autowired GrpcServerLifecycle grpcServer;

    @Test
    void fullSpringContextAndGrpcServerStartTogether() {
        assertThat(grpcServer.isRunning()).isTrue();
    }
}
