package com.materialflow.erp.integration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.materialflow.erp.billing.BillingApplicationService;
import com.materialflow.erp.billing.PaymentFileRequest;
import com.materialflow.erp.billing.ReconciliationApplicationService;
import com.materialflow.erp.fulfillment.CreateShipmentRequest;
import com.materialflow.erp.fulfillment.FulfillmentApplicationService;
import com.materialflow.erp.events.DomainEventInboxApplicationService;
import com.materialflow.erp.order.CreateOrderRequest;
import com.materialflow.erp.order.OrderApplicationService;
import com.materialflow.erp.procurement.CreatePurchaseRequest;
import com.materialflow.erp.procurement.ProcurementApplicationService;
import com.materialflow.erp.procurement.ReceivePurchaseOrderRequest;
import com.materialflow.identity.ActorContext;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import io.micrometer.core.instrument.MeterRegistry;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

@Testcontainers
@SpringBootTest
class BusinessFlowIntegrationTest {
    private static final UUID ORGANIZATION = UUID.fromString("11111111-1111-1111-1111-111111111111");
    private static final UUID CUSTOMER = UUID.fromString("33333333-3333-3333-3333-333333333333");
    private static final UUID SUPPLIER = UUID.fromString("44444444-4444-4444-4444-444444444444");
    private static final UUID CEMENT = UUID.fromString("55555555-5555-5555-5555-555555555555");
    private static final UUID PLYWOOD = UUID.fromString("55555555-5555-5555-5555-555555555556");
    private static final UUID WAREHOUSE = UUID.fromString("22222222-2222-2222-2222-222222222222");
    private static final UUID CEMENT_LOCATION = UUID.fromString("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa1");
    private static final UUID PLYWOOD_LOCATION = UUID.fromString("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa2");
    private static final UUID SALES_USER = UUID.fromString("66666666-6666-6666-6666-666666666601");
    private static final UUID APPROVER_USER = UUID.fromString("66666666-6666-6666-6666-666666666602");
    private static final UUID WAREHOUSE_USER = UUID.fromString("66666666-6666-6666-6666-666666666603");

    @Container
    static final PostgreSQLContainer<?> POSTGRES = new PostgreSQLContainer<>("postgres:17.6-alpine")
            .withDatabaseName("materialflow")
            .withUsername("materialflow")
            .withPassword("materialflow");

    @DynamicPropertySource
    static void database(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", POSTGRES::getJdbcUrl);
        registry.add("spring.datasource.username", POSTGRES::getUsername);
        registry.add("spring.datasource.password", POSTGRES::getPassword);
        registry.add("materialflow.security.enabled", () -> "false");
    }

    @Autowired OrderApplicationService orders;
    @Autowired FulfillmentApplicationService fulfillment;
    @Autowired BillingApplicationService billing;
    @Autowired ReconciliationApplicationService reconciliation;
    @Autowired ProcurementApplicationService procurement;
    @Autowired DomainEventInboxApplicationService inbox;
    @Autowired JdbcTemplate jdbc;
    @Autowired PlatformTransactionManager transactionManager;
    @Autowired MeterRegistry meters;

    @Test
    void orderToCashAndProcurementToReceiptAreIdempotentEndToEnd() throws Exception {
        ActorContext sales = actor(SALES_USER, "SALES_ORDER_WRITE", "PROCUREMENT_WRITE");
        ActorContext finance = actor(APPROVER_USER, "BILLING_WRITE", "RECONCILIATION_WRITE", "PROCUREMENT_APPROVE");
        ActorContext warehouse = actor(WAREHOUSE_USER, "WAREHOUSE_OPERATE");

        var order = orders.create(new CreateOrderRequest(CUSTOMER, false, List.of(
                new CreateOrderRequest.Line(PLYWOOD, WAREHOUSE, PLYWOOD_LOCATION, new BigDecimal("5"),
                        null, null, null))), "e2e-order", sales);
        assertThat(order.status()).isEqualTo("RESERVED");

        UUID reservationId = jdbc.queryForObject(
                "SELECT id FROM inventory_reservations WHERE order_id = ?", UUID.class, order.id());
        var shipmentRequest = new CreateShipmentRequest(List.of(
                new CreateShipmentRequest.Line(reservationId, new BigDecimal("5"))));
        var shipment = fulfillment.ship(order.id(), shipmentRequest, "e2e-shipment", warehouse);
        var shipmentReplay = fulfillment.ship(order.id(), shipmentRequest, "e2e-shipment", warehouse);
        assertThat(shipmentReplay.id()).isEqualTo(shipment.id());
        assertThat(jdbc.queryForObject("SELECT status FROM sales_orders WHERE id = ?", String.class, order.id()))
                .isEqualTo("FULFILLED");

        var invoice = billing.createInvoice(order.id(), "e2e-invoice", finance);
        var invoiceReplay = billing.createInvoice(order.id(), "e2e-invoice", finance);
        assertThat(invoiceReplay.id()).isEqualTo(invoice.id());
        assertThat(invoice.totalAmount()).isEqualByComparingTo("236.25");

        var paymentRequest = new PaymentFileRequest("synthetic-bank-e2e.csv", List.of(
                new PaymentFileRequest.Record("SYN-E2E-0001", invoice.invoiceNumber(), null,
                        invoice.totalAmount(), LocalDate.of(2026, 8, 31))));
        var imported = reconciliation.importFile(paymentRequest, "e2e-payment", finance);
        var importReplay = reconciliation.importFile(paymentRequest, "e2e-payment", finance);
        assertThat(importReplay.fileId()).isEqualTo(imported.fileId());
        assertThat(imported.matchedCount()).isEqualTo(1);
        assertThat(jdbc.queryForObject("SELECT status FROM sales_orders WHERE id = ?", String.class, order.id()))
                .isEqualTo("SETTLED");
        assertThat(jdbc.queryForObject("SELECT credit_used FROM credit_accounts WHERE customer_id = ?",
                BigDecimal.class, CUSTOMER)).isZero();

        var shortOrder = orders.create(new CreateOrderRequest(CUSTOMER, true, List.of(
                new CreateOrderRequest.Line(CEMENT, WAREHOUSE, CEMENT_LOCATION, new BigDecimal("1100"),
                        null, null, null))), "e2e-backorder", sales);
        assertThat(shortOrder.status()).isEqualTo("PARTIALLY_ALLOCATED");
        UUID suggestionId = jdbc.queryForObject(
                "SELECT id FROM procurement_suggestions WHERE order_id = ? AND status = 'OPEN'",
                UUID.class, shortOrder.id());

        var purchaseRequest = new CreatePurchaseRequest(SUPPLIER, List.of(
                new CreatePurchaseRequest.Line(suggestionId, CEMENT_LOCATION,
                        new BigDecimal("100"), new BigDecimal("8.50"))));
        var requested = procurement.create(purchaseRequest, "e2e-purchase-request", sales);
        var approved = procurement.approve(requested.id(), "e2e-purchase-approval", finance);
        UUID purchaseOrderLineId = jdbc.queryForObject(
                "SELECT id FROM purchase_order_lines WHERE purchase_order_id = ?",
                UUID.class, approved.purchaseOrderId());
        var receiptRequest = new ReceivePurchaseOrderRequest(List.of(
                new ReceivePurchaseOrderRequest.Line(purchaseOrderLineId, new BigDecimal("100"))));
        var receipt = procurement.receive(approved.purchaseOrderId(), receiptRequest, "e2e-receipt", warehouse);
        var receiptReplay = procurement.receive(approved.purchaseOrderId(), receiptRequest, "e2e-receipt", warehouse);

        assertThat(receiptReplay.status()).isEqualTo(receipt.status());
        assertThat(receipt.status()).isEqualTo("RECEIVED");
        var inventory = jdbc.queryForMap("""
                SELECT on_hand, reserved, available FROM inventory_balances
                 WHERE organization_id = ? AND warehouse_id = ? AND material_id = ? AND location_id = ?
                """, ORGANIZATION, WAREHOUSE, CEMENT, CEMENT_LOCATION);
        assertThat((BigDecimal) inventory.get("on_hand")).isEqualByComparingTo("1100");
        assertThat((BigDecimal) inventory.get("reserved")).isEqualByComparingTo("1000");
        assertThat((BigDecimal) inventory.get("available")).isEqualByComparingTo("100");

        String receiptEvent = jdbc.queryForObject("""
                SELECT payload::text FROM outbox_events
                 WHERE event_type = 'InventoryReceived' AND aggregate_id = ?
                """, String.class, approved.purchaseOrderId());
        var transaction = new TransactionTemplate(transactionManager);
        var counter = meters.counter("event_processed_total", "consumer", "erp-core-backorder-reallocation-v1");
        double processedBefore = counter.count();
        long outboxBefore = jdbc.queryForObject("SELECT count(*) FROM outbox_events", Long.class);
        long ledgerBefore = jdbc.queryForObject("SELECT count(*) FROM inventory_ledger", Long.class);
        // Inject failure after real side effects, before commit: Inbox, allocation, audit/outbox must roll back together.
        assertThatThrownBy(() -> transaction.executeWithoutResult(status -> {
            assertThat(inbox.consume(receiptEvent).reallocatedLines()).isEqualTo(1);
            throw new IllegalStateException("injected consumer failure before DB commit");
        })).isInstanceOf(IllegalStateException.class).hasMessage("injected consumer failure before DB commit");
        assertThat(jdbc.queryForObject("SELECT count(*) FROM consumer_inbox", Long.class)).isZero();
        assertThat(jdbc.queryForObject("SELECT count(*) FROM outbox_events", Long.class)).isEqualTo(outboxBefore);
        assertThat(jdbc.queryForObject("SELECT count(*) FROM inventory_ledger", Long.class)).isEqualTo(ledgerBefore);
        assertThat(counter.count()).isEqualTo(processedBefore);
        assertThat(jdbc.queryForObject("SELECT reserved FROM inventory_balances WHERE material_id = ?",
                BigDecimal.class, CEMENT)).isEqualByComparingTo("1000");

        var start = new CountDownLatch(1);
        List<DomainEventInboxApplicationService.ProcessingResult> results = new ArrayList<>();
        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            List<Future<DomainEventInboxApplicationService.ProcessingResult>> tasks = new ArrayList<>();
            for (int index = 0; index < 12; index++) tasks.add(executor.submit(() -> {
                start.await();
                return inbox.consume(receiptEvent);
            }));
            start.countDown();
            for (var task : tasks) results.add(task.get(15, TimeUnit.SECONDS));
        }
        assertThat(results.stream().filter(result -> !result.duplicate()).toList()).hasSize(1);
        assertThat(results.stream().filter(DomainEventInboxApplicationService.ProcessingResult::duplicate).toList())
                .hasSize(11);
        var processed = results.stream().filter(result -> !result.duplicate()).findFirst().orElseThrow();
        // Repeat after a successful database commit, as offset redelivery would. No Kafka offset crash is claimed here.
        var duplicate = inbox.consume(receiptEvent);
        assertThat(processed.reallocatedLines()).isEqualTo(1);
        assertThat(duplicate.duplicate()).isTrue();
        assertThat(counter.count()).isEqualTo(processedBefore + 1);
        assertThat(jdbc.queryForObject("SELECT count(*) FROM inventory_ledger", Long.class)).isEqualTo(ledgerBefore + 1);
        assertThat(jdbc.queryForObject("SELECT count(*) FROM outbox_events", Long.class)).isEqualTo(outboxBefore + 1);
        var reallocatedInventory = jdbc.queryForMap("""
                SELECT on_hand, reserved, available FROM inventory_balances
                 WHERE organization_id = ? AND warehouse_id = ? AND material_id = ? AND location_id = ?
                """, ORGANIZATION, WAREHOUSE, CEMENT, CEMENT_LOCATION);
        assertThat((BigDecimal) reallocatedInventory.get("reserved")).isEqualByComparingTo("1100");
        assertThat((BigDecimal) reallocatedInventory.get("available")).isZero();
        assertThat(jdbc.queryForObject("SELECT status FROM sales_orders WHERE id = ?",
                String.class, shortOrder.id())).isEqualTo("RESERVED");
        assertThat(jdbc.queryForObject("SELECT count(*) FROM consumer_inbox WHERE event_id = ?",
                Long.class, processed.eventId())).isEqualTo(1L);
        assertThat(jdbc.queryForObject("SELECT count(*) FROM shipment_lines WHERE shipment_id = ?",
                Long.class, shipment.id())).isEqualTo(1L);
        assertThat(jdbc.queryForObject("SELECT count(*) FROM invoice_lines WHERE invoice_id = ?",
                Long.class, invoice.id())).isEqualTo(1L);
        assertThat(jdbc.queryForObject("SELECT count(*) FROM payment_allocations WHERE invoice_id = ?",
                Long.class, invoice.id())).isEqualTo(1L);
    }

    private ActorContext actor(UUID userId, String... roles) {
        return new ActorContext(userId, ORGANIZATION, Set.of(roles), Set.of(WAREHOUSE));
    }
}
